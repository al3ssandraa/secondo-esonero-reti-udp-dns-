/*
 ============================================================================
 Name        : server_udp.c
 Author      : Alessandra Loiodice
 Version      16 dic 2024
 Copyright   : Your copyright notice
 Description : server
 ============================================================================
 */


#include "common_udp.h"

// Function to generate a numeric password (digits only)
void generate_numeric(char *password, int length) {
   // Loop to generate each digit in the password
   for (int i = 0; i < length; i++) {
       password[i] = '0' + rand() % 10; // Assign a random digit between '0' and '9'
   }
   password[length] = '\0'; // Null-terminate the password
}
// Function to generate an alphabetic password (lowercase letters only)
void generate_alpha(char *password, int length) {
   // Loop to generate each character in the password
   for (int i = 0; i < length; i++) {
       password[i] = 'a' + rand() % 26; // Assign a random lowercase letter from 'a' to 'z'
   }
   password[length] = '\0'; // Null-terminate the password
}
// Function to generate a mixed password (lowercase letters and digits)
void generate_mixed(char *password, int length) {
   // Loop to generate each character in the password
   for (int i = 0; i < length; i++) {
       if (rand() % 2) {
           password[i] = 'a' + rand() % 26; // Random lowercase letter
       } else {
           password[i] = '0' + rand() % 10; // Random digit
       }
   }
   password[length] = '\0'; // Null-terminate the password
}
// Function to generate a secure password (includes uppercase, lowercase, digits, and special symbols)
void generate_secure(char *password, int length) {
   // Define a set of characters for the secure password
   char characters[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}|;:,.<>?";
   // Loop to generate each character in the password
   for (int i = 0; i < length; i++) {
       password[i] = characters[rand() % strlen(characters)]; // Random character from the set
   }
   password[length] = '\0'; // Null-terminate the password
}
// Function to generate an unambiguous secure password (no similar-looking characters)
void generate_unambiguous(char *password, int length) {
   // Define a set of characters for the unambiguous secure password
   char characters[] = "ACDEFGHJKLMNPQRTUVWXYabcdefghjkmnpqrtuvwxy34679!@#$%^&*()-_=+[]{}|;:,.<>?";
   // Loop to generate each character in the password
   for (int i = 0; i < length; i++) {
       password[i] = characters[rand() % strlen(characters)]; // Random character from the set
   }
   password[length] = '\0'; // Null-terminate the password
}
// Function to display the help menu for password generation commands
void display_help_menu() {
   printf("Password Generator Help Menu\n");
   printf(" Commands:\n");
   printf(" h        : Show this help menu\n");
   printf(" n LENGTH : Generate numeric password (digits only)\n");
   printf(" a LENGTH : Generate alphabetic password (lowercase letters)\n");
   printf(" m LENGTH : Generate mixed password (lowercase letters and numbers)\n");
   printf(" s LENGTH : Generate secure password (uppercase, lowercase, numbers, symbols)\n");
   printf(" u LENGTH : Generate unambiguous secure password (no similar-looking characters)\n");
   printf(" q        : Quit application\n");
}
// Main function of the server application
int main(void) {
   // Windows-specific initialization of Winsock
   #if defined WIN32
   WSADATA wsa_data;
   if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
       fprintf(stderr, "WSAStartup failed\n");
       return -1; // Exit with error if Winsock initialization fails
   }
   #endif
   // Create the UDP socket for the server
   int server_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
   if (server_socket < 0) {
       perror("Socket creation failed");
       clearwinsock(); // Cleanup Winsock before exiting
       return -1; // Exit with error if socket creation fails
   }
   // Setup server address structure
   struct sockaddr_in server_addr = {0};
   server_addr.sin_family = AF_INET;
   server_addr.sin_port = htons(PROTOPORT); // Set server port
   server_addr.sin_addr.s_addr = INADDR_ANY; // Accept connections on any network interface
   // Bind the socket to the server address and port
   if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
       perror("Bind failed");
       closesocket(server_socket); // Close socket if binding fails
       clearwinsock(); // Cleanup Winsock before exiting
       return -1; // Exit with error if binding fails
   }
   printf("Server is ready to receive requests...\n");
   // Variables for receiving client requests and sending responses
   struct sockaddr_in client_addr;
   socklen_t client_addr_len = sizeof(client_addr);
   char buffer[BUFFERSIZE];
   while (1) {
       // Receive a request from the client
       int received_bytes = recvfrom(server_socket, buffer, BUFFERSIZE - 1, 0, (struct sockaddr *)&client_addr, &client_addr_len);
       if (received_bytes < 0) {
           perror("Failed to receive data");
           closesocket(server_socket); // Close socket if receiving fails
           clearwinsock(); // Cleanup Winsock before continuing
           continue; // Continue the loop to wait for more requests
       }
       buffer[received_bytes] = '\0'; // Null-terminate the received string
       printf("Received request: %s\n", buffer);
       // Print the client's IP address and port
       #if defined WIN32
       char *client_ip = inet_ntoa(client_addr.sin_addr);
       printf("New request from %s:%d\n", client_ip, ntohs(client_addr.sin_port));
       #else
       char client_ip[INET_ADDRSTRLEN];
       inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, sizeof(client_ip));
       printf("New request from %s:%d\n", client_ip, ntohs(client_addr.sin_port));
       #endif
       // Variable to hold the generated password
       char response[MAX_PASSWORD_LENGTH + 1];
       int length;
       char *endptr;
       // Parse the requested password length from the received request
       length = strtol(&buffer[2], &endptr, 10);
       if (*endptr != '\0' || length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
           // If the length is invalid, send an error message to the client
           char *error_msg = "Password length must be between 6 and 32 characters";
           sendto(server_socket, error_msg, strlen(error_msg), 0, (struct sockaddr *)&client_addr, client_addr_len);
           continue; // Skip further processing and continue the loop
       }
       // Handle the different types of password requests
       switch (buffer[0]) {
           case 'n': // Numeric password request
               generate_numeric(response, length);  // Call the function to generate the password
               break;
           case 'a': // Alphabetic password request
               generate_alpha(response, length);   // Call the function to generate the password
               break;
           case 'm': // Mixed password request
               generate_mixed(response, length);   // Call the function to generate the password
               break;
           case 's': { // Secure password request
               generate_secure(response, length);  // Call the function to generate the password
               break;
           }
           case 'u': // Unambiguous secure password request
               generate_unambiguous(response, length);  // Call the function to generate the password
               break;
           case 'h': // Help menu request
               display_help_menu(); // Display the help menu
               continue;  // Skip sending a response back to the client
               break;
           default:
           {
               // If the request type is invalid, send an error message to the client
               char *error_msg = "Invalid request type";
               sendto(server_socket, error_msg, strlen(error_msg), 0, (struct sockaddr *)&client_addr, client_addr_len);
               continue; // Skip further processing and continue the loop
           }
       }
       // Send the generated password back to the client
       sendto(server_socket, response, strlen(response), 0, (struct sockaddr *)&client_addr, client_addr_len);
   }
   // Clean up the server socket and Winsock
   closesocket(server_socket);
   clearwinsock();
   return 0; // Exit successfully
}
