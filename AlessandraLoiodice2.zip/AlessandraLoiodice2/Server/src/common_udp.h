/*
 * common_udp.h
 *
 *  Created on: 16 dic 2024
 *      Author: Alessandra Loiodice
 */

#ifndef COMMON_UDP_H_
#define COMMON_UDP_H_

// Standard libraries for general functionality
#include <stdio.h>      // For standard input/output operations
#include <stdlib.h>     // For dynamic memory allocation and process control
#include <string.h>     // For string manipulation
#include <ctype.h>      // For character handling functions
#include <time.h>       // For time-related functions

// Platform-specific includes: Handling different operating systems (Windows vs POSIX-based systems)
#if defined WIN32
// Windows-specific socket and networking libraries
#include <winsock2.h>       // For socket management and network communication
#include <ws2tcpip.h>       // For getaddrinfo and freeaddrinfo functions
#include <windows.h>        // For Windows-specific APIs
#include <winbase.h>        // For Windows base functionality (e.g., time-related functions)

// Function to initialize Winsock on Windows
int init_winsock() {
   WSADATA wsaData;
   // Initialize Winsock with version 2.2
   if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
       fprintf(stderr, "WSAStartup failed with error: %d\n", WSAGetLastError());
       return -1;  // Return error code if initialization fails
   }
   return 0;  // Success
}

// Function to clean up Winsock on Windows
void clearwinsock() {
   WSACleanup();  // Clean up Winsock
}

// Redefine close_socket to use 'closesocket' on Windows
#define close_socket closesocket  // Windows uses 'closesocket' for closing sockets

#else  // POSIX (Linux/macOS)
#include <netdb.h>          // For network-related functions (e.g., getaddrinfo, freeaddrinfo)
#include <arpa/inet.h>      // For internet address manipulation (e.g., inet_addr, htons)
#include <unistd.h>         // For POSIX system calls (e.g., close())

// Redefine close_socket to use 'close' on POSIX-based systems (Linux/macOS)
#define close_socket close  // On Unix/Linux, 'close' is used to close a socket
#endif

// Define constants for protocol port, buffer size, and password length limits
#define PROTOPORT 5193              // The port number used by the server for communication
#define BUFFERSIZE 1024             // Size of the buffer used for receiving/sending data
#define MIN_PASSWORD_LENGTH 6       // Minimum length for password generation
#define MAX_PASSWORD_LENGTH 32      // Maximum length for password generation

// Function declarations for resolving hostnames to IP addresses, password generation, and displaying help
int resolve_host_to_ip(const char *hostname, struct sockaddr_in *server_addr);

// Password generation functions for different types of passwords
void generate_numeric(char *password, int length);   // Numeric password (digits only)
void generate_alpha(char *password, int length);     // Alphabetic password (lowercase letters only)
void generate_mixed(char *password, int length);     // Mixed password (letters and digits)
void generate_secure(char *password, int length);    // Secure password (uppercase, lowercase, digits, symbols)
void generate_unambiguous(char *password, int length); // Unambiguous secure password (avoiding similar characters)

// Function to display the help menu for the application
void display_help_menu();


#endif /* COMMON_UDP_H_ */
