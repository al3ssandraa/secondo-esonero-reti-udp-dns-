/*
 ============================================================================
 Name        : client_udp.c
 Author      : Alessandra Loiodice
 Version     : 16 dic 2024
 Copyright   : Your copyright notice
 Description : client
 ============================================================================
 */

#include "common_udp.h"

/**
 * Function to display the help menu with detailed information about the available commands.
 * This menu provides instructions on how to use the password generator and explains each command.
 */
void display_help_menu() {
   printf("Password Generator Help Menu\n");
   printf(" Commands:\n");
   printf(" h        : Show this help menu\n");
   printf(" n LENGTH : Generate numeric password (digits only)\n");
   printf(" a LENGTH : Generate alphabetic password (lowercase letters)\n");
   printf(" m LENGTH : Generate mixed password (lowercase letters and numbers)\n");
   printf(" s LENGTH : Generate secure password (uppercase, lowercase, numbers, symbols)\n");
   printf(" u LENGTH : Generate unambiguous secure password (no similar-looking characters)\n");
   printf(" q        : Quit application\n");
}

/**
 * Function to resolve a hostname to its corresponding IPv4 address.
 * It supports both Windows and Linux/macOS environments by using platform-specific methods.
 *
 * @param hostname The hostname to resolve.
 * @param server_addr Pointer to the sockaddr_in structure where the resolved IP will be stored.
 * @return 0 on success, -1 on failure.
 */
int resolve_host_to_ip(const char *hostname, struct sockaddr_in *server_addr) {
   struct addrinfo hints;  // Specifies criteria for selecting socket address structures.
   struct hostent *he;  // Used for hostname resolution in Windows.

   // Initialize the hints structure to zero and set desired properties.
   memset(&hints, 0, sizeof(hints));
   hints.ai_family = AF_INET;  // Restrict results to IPv4 addresses.
   hints.ai_socktype = SOCK_STREAM;  // Specify stream sockets (TCP).

#if defined WIN32
   // On Windows: Use gethostbyname to resolve the hostname to an IP address.
   he = gethostbyname(hostname);
   if (he == NULL) {
       fprintf(stderr, "Error resolving hostname: %s\n", hostname);
       return -1;  // Return -1 if hostname resolution fails.
   }
   // Copy the resolved IP address into the server_addr structure.
   memcpy(&server_addr->sin_addr, he->h_addr_list[0], he->h_length);
   server_addr->sin_family = AF_INET;  // Set address family to IPv4.
   server_addr->sin_port = htons(80);  // Default port (HTTP).
   printf("Resolved IP for %s: %s\n", hostname, inet_ntoa(server_addr->sin_addr));
   return 0;  // Return 0 to indicate success.
#else
   // On Linux/macOS: Use getaddrinfo for hostname resolution.
   int err;
   struct addrinfo *res;
   err = getaddrinfo(hostname, NULL, &hints, &res);
   if (err != 0) {
       fprintf(stderr, "Error resolving hostname: %s\n", gai_strerror(err));
       return -1;  // Return -1 if hostname resolution fails.
   }
   // Check if the resolved address is IPv4 and copy the address.
   if (res->ai_family == AF_INET) {
       memcpy(&server_addr->sin_addr, &((struct sockaddr_in*)res->ai_addr)->sin_addr, sizeof(struct in_addr));
       server_addr->sin_family = AF_INET;  // Set address family to IPv4.
       server_addr->sin_port = htons(80);  // Default port (HTTP).
       printf("Resolved IP for %s: %s\n", hostname, inet_ntoa(server_addr->sin_addr));
       freeaddrinfo(res);  // Free the memory allocated by getaddrinfo.
       return 0;  // Return 0 to indicate success.
   }
   freeaddrinfo(res);  // Free memory in case of failure.
   return -1;  // Return -1 if the address is not IPv4.
#endif
}

/**
 * Entry point of the application.
 * This function initializes resources, processes user commands, and manages the communication with the password generator server.
 *
 * @return 0 on successful execution, -1 on error.
 */
int main(void) {
   #if defined WIN32
   WSADATA wsa_data;
   // Initialize the Winsock library on Windows.
   if (WSAStartup(MAKEWORD(2, 2), &wsa_data) != 0) {
       fprintf(stderr, "WSAStartup failed\n");
       return -1;  // Return -1 if Winsock initialization fails.
   }
   #endif

   // Create a UDP socket for communication with the server.
   int client_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
   if (client_socket < 0) {
       perror("Socket creation failed");
       return -1;  // Return -1 if socket creation fails.
   }
   printf("Client socket created successfully.\n");

   struct sockaddr_in server_addr = {0};  // Zero out the server address structure.
   server_addr.sin_family = AF_INET;  // Set address family to IPv4.
   const char *hostname = "passwdgen.uniba.it";  // Server hostname.

   // Resolve the server hostname to its IP address.
   if (resolve_host_to_ip(hostname, &server_addr) != 0) {
       close_socket(client_socket);  // Close the socket on error.
       clearwinsock();  // Clean up Winsock resources (Windows only).
       return -1;  // Return -1 if hostname resolution fails.
   }
   server_addr.sin_port = htons(PROTOPORT);  // Set the server port.
   printf("Resolved IP for %s: %s\n", hostname, inet_ntoa(server_addr.sin_addr));

   char input[BUFFERSIZE];  // Buffer to store user input.
   int running = 1;  // Flag to control the main application loop.

   // Main loop to process user commands.
   while (running) {
       printf("\nType a command (use 'h' for help): ");
       fgets(input, sizeof(input), stdin);  // Read user input from the console.
       input[strcspn(input, "\n")] = 0;  // Remove newline character from input.

       // Check if the user wants to quit the application.
       if (input[0] == 'q') {
           printf("Quitting the application...\n");
           running = 0;  // Exit the loop.
       } else if (input[0] == 'h') {
           display_help_menu();  // Display the help menu.
       } else if ((input[0] == 'n' || input[0] == 'a' || input[0] == 'm' || input[0] == 's' || input[0] == 'u') && input[1] == ' ') {
           // Validate the input for password generation commands.
           int length = atoi(&input[2]);  // Extract the password length from input.
           if (length < MIN_PASSWORD_LENGTH || length > MAX_PASSWORD_LENGTH) {
               printf("Invalid length. Please provide a valid length (%d-%d).\n", MIN_PASSWORD_LENGTH, MAX_PASSWORD_LENGTH);
           } else {
               // Prepare the message to send to the server.
               char message[BUFFERSIZE];
               snprintf(message, sizeof(message), "%c %d", input[0], length);

               // Send the password generation request to the server.
               if (sendto(client_socket, message, strlen(message), 0, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
                   perror("Failed to send request to server");
               } else {
                   printf("Password generation request sent to the server...\n");
                   char response[BUFFERSIZE];  // Buffer to store the server's response.
                   socklen_t server_len = sizeof(server_addr);  // Server address length.
                   int received = recvfrom(client_socket, response, sizeof(response) - 1, 0, (struct sockaddr *)&server_addr, &server_len);
                   if (received < 0) {
                       perror("Failed to receive response from server");
                   } else {
                       response[received] = '\0';  // Null-terminate the received string.
                       printf("Response received from the server: %s\n", response);  // Print the server's response.
                   }
               }
           }
       } else {
           // Handle invalid commands.
           printf("Invalid command. Use 'h' for help.\n");
       }
   }

   // Close the socket and clean up resources before exiting.
   close_socket(client_socket);
   clearwinsock();
   return 0;  // Exit the application successfully.
}
